const inputtype=["button","checkbox","color","date","datetime","email","file","hidden","image","month","number","password","radio","range",
"reset","search","submit","tel","text","time","url","week"];
const datatype=["String","Number","Integer","Image","URL"];
const controltype=["input","textarea","select"];

export default  {inputtype,datatype,controltype}