import axios from 'axios';
import { resolve } from './resolve.js';
export default () => axios.get('/');  
export async function login() {
  return await resolve(axios.get('http://localhost:3000/api/abhita/getAdminMasterDetail').then(res => res.data));
}

export async function getUser(id) {
  return await axios.get(`http://some-api.com/users/${id}`).then(res => res.data);
}
export async function IU_AdminMaster() {
  return await axios.post(`http://localhost:3000/api/abhita/iuadminmaster`).then(res => res.data);
}