const getproperty="getProperty";//'http://localhost:3000/api/property/getproperty';
export default {getproperty}